#pragma once
class Vector
{
public:
	float x, y;

	Vector();
	Vector(float x, float y);
	
};

