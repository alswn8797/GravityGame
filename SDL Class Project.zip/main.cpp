#include <iostream>
#include <string>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include "Animation.h"
#include "KeyboardHandler.h"
#include "MouseHandler.h"
#include "GameObject.h"
#include <list>
#include "Crow.h"

using namespace std;

int main(int argc, char **argv){
	//initialise SDL with the subsystems you wish to use
	//ie SDL_INIT_VIDEO, but we'll launch all subsystems (input, video, etc)
	if (SDL_Init(SDL_INIT_EVERYTHING) != 0)
	{
		cout << "SDL failed to initialise" << endl;
		return -1;
	}
	cout << "SDL successfully initialised!" << endl;

	//Initialise SDL_Image
	if (!(IMG_Init(IMG_INIT_PNG)&IMG_INIT_PNG))
	{
		cout << "sdl image did not load: " << IMG_GetError() << endl;
		SDL_Quit();
		system("pause");
		return -1;
	}

	//Initialise TTF
	if (TTF_Init() != 0){
		//if failed
		cout << "SDL TTF FAILED!" << endl;
		system("pause");
		SDL_Quit();
		return -1;
	}

	//Lets create a window to draw into
	//params: title of window
	//		  x and y of where to put this window (we are just centering it)
	//	      width and height of window in pixels
	//		  flags to help decide what type of window to use
	SDL_Window* window = SDL_CreateWindow("Gravity Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
		800, 600, SDL_WINDOW_SHOWN); //for full screen use SDL_WINDOW_SHOWN | SDL_WINDOW_FULLSCREEN

	//did it work?
	if (window != NULL)
		cout << "Window created!" << endl;
	else
	{
		cout << "Window failed!" << endl;
		return -1;
	}

	//Add event hendler
	KeyboardHandler keyboardHandler;
	MouseHandler mouseHandler;

	//Lets build renderer next, its used to help draw stuff to the screen
		//params: window to create renderer for, render driver index(-1, get first best match), flags for what renderer can handle
	SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	//did it work?
	if (renderer != NULL){
		cout << "renderer created!" << endl;
	}
	else
	{
		cout << "renderer failed!" << endl;
		return -1;
	}

	//Load up our font
	//								font file path                font size
	TTF_Font* font = TTF_OpenFont("assets/vermin_vibes_1989.ttf", 100);
	//create a colour for our text
	SDL_Color textcolour = { 255, 255, 255, 0 };//RGBA
	//Create surface using font, colour and desired output text
	SDL_Surface* textSurface = TTF_RenderText_Blended(font, "GRAVITY GAME", textcolour);
	//convert surface to texture
	SDL_Texture* textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
	//dont need the surface no more
	SDL_FreeSurface(textSurface);

	//setup rectangle to describe where to draw this text
	SDL_Rect textDestination;
	textDestination.x = 100;
	textDestination.y = 80;
	//to get the width and height, query the surface
	SDL_QueryTexture(textTexture, NULL, NULL, &textDestination.w, &textDestination.h);

	//load up button text
	//								font file path                font size
	TTF_Font* buttonfont = TTF_OpenFont("assets/Roboto-Black.ttf", 25);
	//create a colour for our text
	//Create surface using font, colour and desired output text
	SDL_Surface* buttonSurface = TTF_RenderText_Blended(buttonfont, "START GAME", textcolour);
	//convert surface to texture
	SDL_Texture* buttonTexture = SDL_CreateTextureFromSurface(renderer, buttonSurface);
	//dont need the surface no more
	SDL_FreeSurface(buttonSurface);

	//setup rectangle to describe where to draw this text
	SDL_Rect buttonDestination;
	buttonDestination.x = 300;
	buttonDestination.y = 350;
	//to get the width and height, query the surface
	SDL_QueryTexture(buttonTexture, NULL, NULL, &buttonDestination.w, &buttonDestination.h);

	//load up background
	SDL_Texture* bgTexture = IMG_LoadTexture(renderer, "assets/main-bg.png");

	//which region of the texture to copy from
	SDL_Rect bgSourceRect;
	//region on the screen to copy source to (can be different sizes, will stretch)
	SDL_Rect bgDestinationRect;

	bgSourceRect.x = 0;
	bgSourceRect.y = 0;
	bgSourceRect.w = 800;
	bgSourceRect.h = 188;
	//destination
	//make it the same size as the image but draw it 50 pixels down and across
	bgDestinationRect.x = 0;
	bgDestinationRect.y = 412;
	bgDestinationRect.w = bgSourceRect.w;
	bgDestinationRect.h = bgSourceRect.h;

	//Load up Run Image
	SDL_Surface* flyCrowSurface = IMG_Load("assets/crow-fly.png");
	SDL_Texture* flyCrowTexture = SDL_CreateTextureFromSurface(renderer, flyCrowSurface);
	Animation flyCrowAnim(flyCrowTexture, renderer, 6, 60, 60, 0.04);
	//cleanup surface
	SDL_FreeSurface(flyCrowSurface);

	//LIST OF ALL GAME OBJECTS
	list<GameObject*> gameObjects;

	//BUILD A CROW
	Crow* flyCrow = new Crow();
	flyCrow->setRenderer(renderer);
	flyCrow->setAnimation(&flyCrowAnim);
	flyCrow->pos.x = 200;
	flyCrow->pos.y = 200;
	flyCrow->velocity.x = 20;
	gameObjects.push_back(flyCrow);

	flyCrow->draw();
	//setup time stuff
	Uint32 lastUpdate = SDL_GetTicks();//milliseconds since the start of the game running

	float frameTimer = 0.083;//83 milliseconds per frame

	int framesCounted = 0;
	float oneSecondTimer = 1;

	float millisecondsInASecond = 1000;

	bool loop = true;
	while (loop)
	{
		//TIME!!!!
		//===================
		//get difference between currentTime running minus the last update time
		Uint32 timeDiff = SDL_GetTicks() - lastUpdate;
		//convert to deltaTime (decimal)
		float dt = timeDiff / millisecondsInASecond;//e.g 200ms is now represented as 0.2 for dt
		//update lastUpdate to currentTime
		lastUpdate = SDL_GetTicks();
		//lets see dt per frame
		cout << "dt = " << dt << endl;

		//set drawing colour for sdl
		//params: which renderer to set colour for, Red, Green, Ble, Alpha where each colour value is 0 - 255
		SDL_SetRenderDrawColor(renderer, 0, 84, 165, 255);
		//clear screen with current draw colour
		SDL_RenderClear(renderer);
		
		flyCrowAnim.update(dt);
		flyCrowAnim.draw(0, 0);

		//DRAW text
		SDL_RenderCopy(renderer, textTexture, NULL, &textDestination);

		//DRAW button
		SDL_RenderCopy(renderer, buttonTexture, NULL, &buttonDestination);

		//DRAW OUR BACKGROUND
		SDL_RenderCopy(renderer, bgTexture, &bgSourceRect, &bgDestinationRect);

		framesCounted++;
		oneSecondTimer -= dt;//minusing how many milliseconds since last game loop cycle

		//1 second has passed
		if (oneSecondTimer <= 0)
		{
			//move crow

			cout << "FPS = " << framesCounted << " dt = "<<dt<< endl;
			framesCounted = 0;
			oneSecondTimer = 1;
		}

		//CHECK FOR INPUTS
		SDL_Event event;
		//loop through all input events (reuse event object each time, just change values in it)
		while (SDL_PollEvent(&event)){
			//check if user has closed window
			if (event.type == SDL_QUIT){
				//exit loop
				loop = false;
			}
			//check if keyboard button pressed
			if (event.type == SDL_KEYDOWN){
				//check if ESC key pressed
				if (event.key.keysym.scancode == SDL_SCANCODE_ESCAPE){
					//exit loop
					loop = false;
				}
				//space barrr
				/*if (event.key.keysym.scancode == SDL_SCANCODE_SPACE && event.key.repeat == 0){
					SoundManager::soundManager.playSound("explode");
				}
				*/
			}
			mouseHandler.update(&event);
		}

		//render textTexture
		SDL_RenderCopy(renderer, textTexture, NULL, &textDestination);

		//update all game objects in list
		/*for (list<GameObject*>::iterator go = gameObjects.begin(); go != gameObjects.end(); go++){
		(*go)->update(dt);
		(*go)->draw();
		}*/
		for each (GameObject* go in gameObjects)
		{
			go->update(dt);
			go->draw();
		}

		//when done drawing, present all our renderings to the window
		SDL_RenderPresent(renderer);

	}
	//SDL_Delay(5000);//pause code for how many milliseconds

	//cleanup
	SDL_DestroyTexture(flyCrowTexture);
	SDL_DestroyTexture(textTexture);
	SDL_DestroyTexture(buttonTexture);
	SDL_DestroyTexture(bgTexture);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	//shut down sdl sub systems
	SDL_Quit();

	system("pause");
	return 0;
}